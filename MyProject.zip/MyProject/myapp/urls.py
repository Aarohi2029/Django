from django.urls import path,include
from . import views

urlpatterns = [
    path('',views.index,name='index'),
    path('about/',views.about,name='about'),
    path('blog_list/',views.blog_list,name='blog_list'),
    path('contact/',views.contact,name='contact'),
    path('product/',views.product,name='product'),
    path('testimonial/',views.testimonial,name='testimonial'),
    path('signup/',views.signup,name='signup'),
    path('login/',views.login,name='login'),
    path('logout/',views.logout,name='logout'),
    path('profile/',views.profile,name='profile'),
    path('change-password/',views.change_password,name='change-password'),
    path('forgot-password/',views.forgot_password,name='forgot-password'),
    path('verify-otp/',views.verify_otp,name='verify-otp'),
    path('update-password/',views.update_password,name='update-password'),
]